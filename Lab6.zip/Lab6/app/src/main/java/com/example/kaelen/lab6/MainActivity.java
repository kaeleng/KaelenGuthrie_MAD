package com.example.kaelen.lab6;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button button = (Button)findViewById(R.id.button);

        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                findDrink(view);
            }
        };

        button.setOnClickListener(onclick);
    }

    private Drink newUserDrink = new Drink();

    public void findDrink(View view){
        Spinner drinkSpinner = (Spinner)findViewById(R.id.spinner);
        Integer drink = drinkSpinner.getSelectedItemPosition();

        ToggleButton toggle = (ToggleButton) findViewById(R.id.toggleButton);
        boolean coffee = toggle.isChecked();

        newUserDrink.setDrinkInfo(coffee,drink);

        String suggestedCoffeeDrink = newUserDrink.getUserDrink();

        Intent intent = new Intent(this,ReceiveDrink.class);

        intent.putExtra("drinkName", suggestedCoffeeDrink);

        startActivity(intent);

    }
}
