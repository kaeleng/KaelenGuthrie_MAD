package com.example.kaelen.lab6;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class ReceiveDrink extends AppCompatActivity {

    private String userDrink;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receive_drink);

        Intent intent = getIntent();
        userDrink = intent.getStringExtra("drinkName");

        TextView messageView = (TextView) findViewById(R.id.drinkText);
        messageView.setText("You should order a " + userDrink);

    }



}
