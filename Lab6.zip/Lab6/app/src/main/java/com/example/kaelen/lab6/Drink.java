package com.example.kaelen.lab6;

/**
 * Created by Kaelen on 12/1/2017.
 */

public class Drink {
    private String userDrink;


    private void coffeeDrink(Boolean drinkType, Integer specificDrink) {
        if(drinkType){
            switch(specificDrink){
                case 0:
                    userDrink = "Coffee with cream and sugar";
                    break;
                case 1:
                    userDrink = "Black Coffee";
                    break;
                case 2:
                    userDrink = "Iced coffee";
                    break;
            }
        }else{
            switch(specificDrink){
                case 0:
                    userDrink = "Vanilla Latte";
                    break;
                case 1:
                    userDrink = "Cappucino";
                    break;
                case 2:
                    userDrink = "Iced Latte";
                    break;
            }
        }
    }

    public void setDrinkInfo(Boolean drinkType, Integer specificDrink){
        coffeeDrink(drinkType,specificDrink);
    }

    public String getUserDrink(){
        return userDrink;
    }

}