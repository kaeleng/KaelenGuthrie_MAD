package com.example.kaelen.guthriefinal;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    private Burrito myBurrito = new Burrito();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button button = (Button) findViewById(R.id.button2);
        //create listener
        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                findBurrito(view);
            }
        };
        //add listener to the button
        button.setOnClickListener(onclick);
    }



public void buildBurrito(View view){
    ToggleButton toggle = (ToggleButton) findViewById(R.id.toggleButton);
    boolean veggie = toggle.isChecked();

    Spinner location = (Spinner) findViewById(R.id.spinner);
    Integer burritoLocation = location.getSelectedItemPosition();
    myBurrito.setBurritoShop(burritoLocation);
    myBurrito.setBurritoShopURL(burritoLocation);

    String suggestedBurritoPlace = myBurrito.getBurritoShop();

    RadioGroup food = (RadioGroup) findViewById(R.id.radioGroup);
    int food_id = food.getCheckedRadioButtonId();

    EditText name = (EditText)findViewById(R.id.editText2);
    String burritoName = name.getText().toString();

    Switch gfSwitch = (Switch)findViewById(R.id.switch1);
    boolean gf = gfSwitch.isChecked();

    ImageView foodPic = (ImageView)findViewById(R.id.imageView);



    String fillingType;
    String burritoPlace;
    String shellType;
    String type;

    if (veggie) {
        fillingType = "veggie";
    }else{
        fillingType = "meat";
    }

    if(gf){
        type = "corn tortilla";
    }else{
        type = "flour tortilla";
    }

    if(food_id == R.id.radioButtonBurrito){
        shellType = "burrito";
        foodPic.setImageResource(R.drawable.burrito);

    }else{
        shellType = "taco";
        foodPic.setImageResource(R.drawable.taco);
    }

    switch(burritoLocation){
        case 0:
            burritoPlace = "29th Street";
            break;
        case 1:
            burritoPlace = "The Hill";
            break;
        case 2:
            burritoPlace = "Pearl Street";
            break;

        default:
            burritoPlace = "somewhere else";
    }



    TextView burritoDetails = (TextView) findViewById(R.id.editText3);
    burritoDetails.setText("The " + burritoName + " is a " + fillingType + " " + shellType + " on a " + type + " that you'd like to eat on " + burritoPlace);


}

    public void findBurrito(View view){
        String suggestedBurritoPlace = myBurrito.getBurritoShop();
        String suggestedBurritoPlaceURL = myBurrito.getBurritoShopURL();

        Intent intent = new Intent(this, FindBurritoActivity.class);
        intent.putExtra("burritoShopName",suggestedBurritoPlace);
        intent.putExtra("burritoShopURL",suggestedBurritoPlaceURL);

        startActivity(intent);
    }
}
