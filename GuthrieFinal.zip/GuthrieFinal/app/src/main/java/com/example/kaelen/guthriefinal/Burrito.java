package com.example.kaelen.guthriefinal;

/**
 * Created by Kaelen on 12/17/2017.
 */

public class Burrito {
  private String burritoShop;
  private String burritoShopURL;

  private void setUserBurritoShop(Integer burritoPlace){
      switch(burritoPlace){
          case 0:
              burritoShop ="Chipotle";
              burritoShopURL = "https://www.chipotle.com/";
              break;
          case 1:
              burritoShop = "Illegal Pete's";
              burritoShopURL = "http://illegalpetes.com/";
              break;
          case 2:
              burritoShop = "Bartaco";
              burritoShopURL = "https://bartaco.com/";
              break;
      }
  }

  public void setBurritoShop(Integer burritoPlace){
      setUserBurritoShop(burritoPlace);
  }

  public void setBurritoShopURL(Integer burritoPlace){
      setUserBurritoShop(burritoPlace);
  }

  public String getBurritoShopURL(){
      return burritoShopURL;
  }

  public String getBurritoShop(){
      return burritoShop;
  }
}
