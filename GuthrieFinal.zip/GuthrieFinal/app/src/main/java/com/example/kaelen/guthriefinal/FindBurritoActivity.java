package com.example.kaelen.guthriefinal;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class FindBurritoActivity extends AppCompatActivity {

    private String burritoShop;
    private String burritoShopURL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_burrito);

        Intent intent = getIntent();
        burritoShop = intent.getStringExtra("burritoShopName");
        burritoShopURL = intent.getStringExtra("burritoShopURL");

        TextView messageView = (TextView) findViewById(R.id.textView3);
        messageView.setText("You should go to " + burritoShop);

        final ImageButton imageButton = (ImageButton) findViewById(R.id.imageButton);

        View.OnClickListener onlick = new View.OnClickListener(){
            public void onClick(View view){
                loadWebSite(view);
            }
        };
    }

    public void loadWebSite(View view){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(burritoShopURL));
        startActivity(intent);
    }

}
