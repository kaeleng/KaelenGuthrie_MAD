package com.example.kaelen.hike;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void findHike(View view){
        ToggleButton toggle = (ToggleButton) findViewById(R.id.toggleButton);
        boolean location = toggle.isChecked();

        Spinner length = (Spinner) findViewById(R.id.spinner);
        String hikeLength = String.valueOf(length.getSelectedItem());

        RadioGroup difficulty = (RadioGroup) findViewById(R.id.radioGroup);
        int difficulty_id = difficulty.getCheckedRadioButtonId();

        String perfectHike = null;

        if(difficulty_id == -1) {
            //toast
            Context context = getApplicationContext();
            CharSequence text = "Please select a difficulty level";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }
        else{
            //far
            if(location){
                //easy
                if(difficulty_id == R.id.radioButton){
                    switch(hikeLength){
                        case "Short":
                            perfectHike = "Adams Falls Trail";
                            break;
                        case "Long":
                            perfectHike = "Castlewood Canyon Trails";
                            break;
                    }
                }
                //medium
                if(difficulty_id == R.id.radioButton2){
                    switch(hikeLength){
                        case "Short":
                            perfectHike = "9 Mile Trail";
                            break;
                        case "Long":
                            perfectHike = "Mount Bierstadt";
                            break;
                    }
                }
                //difficult
                if(difficulty_id == R.id.radioButton3){
                    switch(hikeLength){
                        case "Short":
                            perfectHike = "Snow Mountain";
                            break;
                        case "Long":
                            perfectHike = "Devil's Thumb";
                            break;
                    }
                }

            }
            //close
            else{
                //easy
                if(difficulty_id == R.id.radioButton){
                    switch(hikeLength){
                        case "Short":
                            perfectHike = "Chautauqua Trail";
                            break;
                        case "Long":
                            perfectHike = "Boulder Creek Trail";
                            break;
                    }
                }
                //medium
                if(difficulty_id == R.id.radioButton2){
                    switch(hikeLength){
                        case "Short":
                            perfectHike = "Red Rocks Trail";
                            break;
                        case "Long":
                            perfectHike = "Mount Sanitas";
                            break;
                    }
                }
                if(difficulty_id == R.id.radioButton3){
                    switch(hikeLength){
                        case "Short":
                            perfectHike = "First Flatiron";
                            break;
                        case "Long":
                            perfectHike = "Royal Arch Trail";
                            break;
                    }
                }
            }
            ImageView pic = (ImageView)findViewById(R.id.imageView);
            pic.setImageResource(R.drawable.hike);

            TextView hikeSelection = (TextView) findViewById(R.id.hikeTextView);
            hikeSelection.setText(perfectHike);
        }
    }


}
