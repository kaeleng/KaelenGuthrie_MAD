package com.example.kaelen.hikefinder;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class ReceiveHikeActivity extends AppCompatActivity {

    private String hikeOptionOne;
    private String hikeOptionTwo;
    private String hikeInfoOne;
    private String hikeInfoTwo;
    private String userHikeLatOne;
    private String userHikeLongOne;
    private String userHikeLatTwo;
    private String userHikeLongTwo;
    private String userHikeImageOne;
    private String userHikeImageTwo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receive_hike);

        Intent intent = getIntent();

        hikeOptionOne = intent.getStringExtra("hikeNameOne");
        hikeOptionTwo = intent.getStringExtra("hikeNameTwo");

        hikeInfoOne = intent.getStringExtra("infoOne");
        hikeInfoTwo = intent.getStringExtra("infoTwo");

        userHikeLatOne = intent.getStringExtra("latOne");
        userHikeLongOne = intent.getStringExtra("longOne");
        userHikeLatTwo = intent.getStringExtra("latTwo");
        userHikeLongTwo = intent.getStringExtra("longTwo");
    //    userHikeLatOne = intent.getDoubleExtra("userHikeLatOne",0);
     //   userHikeLatOne = intent.getExtras().getDouble("userHikeLatOne");
     //   userHikeLongOne = intent.getDoubleExtra("userHikeLongOne",0);

        userHikeImageOne = intent.getStringExtra("hikeImageOne");
        userHikeImageTwo = intent.getStringExtra("hikeImageTwo");

        ImageView picOne = findViewById(R.id.hikeOneImage);
      //  picOne.setImageResource(R.drawable.devilsthumb);
        picOne.setImageResource(Integer.parseInt(userHikeImageOne));

        ImageView picTwo = (ImageView) findViewById(R.id.hikeTwoImage);
        picTwo.setImageResource(Integer.parseInt(userHikeImageTwo));


        TextView messageView = (TextView) findViewById(R.id.hikeOneTextView);
        messageView.setText(hikeOptionOne);

        TextView messageView2 = (TextView) findViewById(R.id.hikeTwoTextView);
        messageView2.setText(hikeOptionTwo);

        final Button button = (Button) findViewById(R.id.firstChoiceButton);
        final Button button2 = (Button) findViewById(R.id.secondChoiceButton);

        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                getInfo(view);
            }
        };
        button.setOnClickListener(onclick);
        button2.setOnClickListener(onclick);
    }

    private Hike userHike = new Hike();

    public void getInfo(View view){

        Intent intent = new Intent(this,HikeInfoActivity.class);



        switch(view.getId()){
            case R.id.firstChoiceButton:
                String chosenHike = hikeOptionOne;
                String info = hikeInfoOne;
                String lat = userHikeLatOne;
                String longitude = userHikeLongOne;
                String image = userHikeImageOne;
                intent.putExtra("userImage",image);
                intent.putExtra("userLong",longitude);
                intent.putExtra("userLat",lat);
                intent.putExtra("userInfo",info);
                intent.putExtra("userChosenHike",chosenHike);
               // Log.i("Hike1",chosenHike);
                break;
            case R.id.secondChoiceButton:
                chosenHike = hikeOptionTwo;
                info = hikeInfoTwo;
                lat = userHikeLatTwo;
                longitude = userHikeLongTwo;
                image = userHikeImageTwo;
                intent.putExtra("userImage",image);
                intent.putExtra("userLat",lat);
                intent.putExtra("userLong", longitude);
                intent.putExtra("userInfo",info);
                intent.putExtra("userChosenHike", chosenHike);
                break;
        }

        startActivity(intent);
    }
}
