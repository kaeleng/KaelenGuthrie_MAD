package com.example.kaelen.hikefinder;

/**
 * Created by Kaelen on 12/4/2017.
 */

public class Hike {
    private String hikeOptionOne;
    private String hikeOptionTwo;
    private String hikeOptionOneInfo;
    private String hikeOptionTwoInfo;
    private String latOne;
    private String longOne;
    private String latTwo;
    private String longTwo;
    private String imageNameOne;
    private String imageNameTwo;

    private void hikeInfo(Integer hikeDifficulty, Integer hikeLength){

        //short and easy
        if(hikeDifficulty == R.id.radioButton && hikeLength==R.id.radioButton4){
            hikeOptionOne = "Adams Falls Trail";
            hikeOptionOneInfo = "The hike to Adams Falls begins from the East Inlet Trailhead near the town of Grand Lake on the west side of Rocky Mountain National Park. As the trail proceeds towards Adams Falls it passes through a mixed forest of pine and aspens.";
            latOne = Double.toString(40.2398);
            longOne = Double.toString(-105.80001);
            imageNameOne = "adamsfalls";
            hikeOptionTwo = "Red Rocks Trail";
            hikeOptionTwoInfo = "Not to be confused with Red Rocks in Denver, this trail is in Settlers Park in Boulder. Hike around beautiful sandstone red rock formations.";
            latTwo = Double.toString(40.013742);
            longTwo = Double.toString( -105.296036);
            imageNameTwo = "redrocks";
        }
        //short and medium
        else if(hikeDifficulty == R.id.radioButton2 && hikeLength == R.id.radioButton4){
            hikeOptionOne = "Mount Sanitas";
            hikeOptionOneInfo = "This trail features beautiful wildflowers and views to the east and west as you hike to the summit of Mount Sanitas.";
            latOne = Double.toString(40.019960);
            longOne = Double.toString(-105.298183);
            imageNameOne = "sanitas";
            hikeOptionTwo = "Rattlesnake Gulch";
            hikeOptionTwoInfo = "This trail takes you up the sides of Eldorado Canyon. This hike features wildflowers, hotel ruins, and views of the Continental Divide.";
            latTwo = Double.toString(39.9295090);
            longTwo = Double.toString(-105.2901360);
            imageNameTwo = "ratlesnake";
        }
        //short and hard
        else if(hikeDifficulty == R.id.radioButton3 && hikeLength==R.id.radioButton4){
            hikeOptionOne = "1st & 2nd Flatiron";
            hikeOptionOneInfo = "This trail begins in a green meadow and goes up between the First and Second Flatiron. At the end of the trail you will find breathtaking views of the Rocky Mountains and the eastern plains.";
            latOne = Double.toString(39.998995);
            longOne = Double.toString(-105.282979);
            imageNameOne = "flatirons";
            hikeOptionTwo = "Royal Arch Trail";
            hikeOptionTwoInfo = "This trail features many uphill and downhill portions and brings you to the beautiful Royal Arch.";
            latTwo = Double.toString(39.998995);
            longTwo = Double.toString(-105.282979);
            imageNameTwo = "royalarch";
        }
        //long and easy
        else if(hikeDifficulty == R.id.radioButton && hikeLength == R.id.radioButton5){
            hikeOptionOne = "Guanella Pass Trail";
            hikeOptionOneInfo = "This trail offers the chance to see wildlife and is a great place to view the beautiful fall colors";
            latOne = Double.toString(39.596363);
            longOne = Double.toString( -105.710221);
            imageNameOne = "guanella";
            hikeOptionTwo = "Clear Creek Trail";
            hikeOptionTwoInfo = "This paved trail runs along a creek and has views of the North and South Table Mountains. This trail goes by many lakes, schools, and parks";
            latTwo = Double.toString(39.772281);
            longTwo = Double.toString(-105.180256);
            imageNameTwo = "clearcreek";
        }
        //long and medium
        else if(hikeDifficulty == R.id.radioButton2 && hikeLength == R.id.radioButton5){
            hikeOptionOne = "Mount Bierstadt";
            hikeOptionOneInfo = "Climb one of Colorado's favorite 14ers and find views of lakes and mountains. The peak of Mount Bierstadt is 14,065 feet";
            latOne = Double.toString(39.596363);
            longOne = Double.toString( -105.710221);
            imageNameOne = "bierstadt";
            hikeOptionTwo = "Chasm Lake";
            hikeOptionTwoInfo = "Starting in a forest of trees, this hike goes along creeks, over rocks, and through subalpine zone. The reward of this hike is the beautiful mountain lake that lies at the base of Longs Peak and Mount Lady Washington.";
            latTwo = Double.toString(40.27215);
            longTwo = Double.toString(-105.55682	);
            imageNameTwo = "chasmlake";
        }
        //long and hard
        else if(hikeDifficulty == R.id.radioButton3 && hikeLength == R.id.radioButton5){
            hikeOptionOne = "Devil's Thumb";
            hikeOptionOneInfo = "This trail goes through forest, fields of wildflowers, and along creeks and lakes. There also good chances of moose sightings on this trail.";
            latOne = Double.toString(39.98656);
            longOne = Double.toString(-105.74282);
            imageNameOne = "devilsthumb";
            hikeOptionTwo = "Mount Elbert";
            hikeOptionTwoInfo = "This is Colorado's tallest mountain at 14,439 feet. This trail begins in forests of aspen trees and ends with beautiful views of the Rocky Mountains";
            latTwo = Double.toString(39.105775);
            longTwo = Double.toString( -106.395331);
            imageNameTwo = "elbert";

        }
    }

    public void setHikeInfo(Integer hikeDifficulty, Integer hikeLength){
        hikeInfo(hikeDifficulty,hikeLength);
    }

    public String getHikeOptionOne(){
        return hikeOptionOne;
    }

    public String getHikeOptionTwo(){
        return hikeOptionTwo;
    }

    public String getHikeOptionOneInfo(){return hikeOptionOneInfo;}

    public String getHikeOptionTwoInfo() {return hikeOptionTwoInfo;}

    public String getLatOne() {return latOne;}

    public String getLongOne(){return longOne;}

    public String getLatTwo() {return latTwo;}

    public String getLongTwo() {return longTwo;}

    public String getImageNameOne() {return imageNameOne;}

    public String getImageNameTwo() {return imageNameTwo;}
}
