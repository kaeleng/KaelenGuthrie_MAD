package com.example.kaelen.hikefinder;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button button = (Button) findViewById(R.id.button);

        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                findHike(view);
            }
        };
        button.setOnClickListener(onclick);
    }

    private Hike userHikeOption = new Hike();


    public void findHike(View view){
        Intent intent = new Intent(this,ReceiveHikeActivity.class);


        RadioGroup difficulty = (RadioGroup) findViewById(R.id.radioGroup);
        int difficulty_id = difficulty.getCheckedRadioButtonId();

        RadioGroup length = (RadioGroup) findViewById(R.id.radioGroup2);
        int length_id = length.getCheckedRadioButtonId();

        userHikeOption.setHikeInfo(difficulty_id,length_id);

        if(difficulty_id == -1 || length_id == -1){
            //toast
            Context context = getApplicationContext();
            CharSequence text = "Please select a hike difficulty and length";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }
        else {
            String suggestedHikeOne = userHikeOption.getHikeOptionOne();
            String suggestedHikeTwo = userHikeOption.getHikeOptionTwo();

            String hikeInfoOne = userHikeOption.getHikeOptionOneInfo();
            String hikeInfoTwo = userHikeOption.getHikeOptionTwoInfo();

            String hikeLatOne = userHikeOption.getLatOne();
            String hikeLongOne = userHikeOption.getLongOne();
            String hikeLatTwo = userHikeOption.getLatTwo();
            String hikeLongTwo = userHikeOption.getLongTwo();

            String imageOne = userHikeOption.getImageNameOne();
            String imageTwo = userHikeOption.getImageNameTwo();

            String mDrawableNameOne = imageOne;
            int resIDOne = getResources().getIdentifier(mDrawableNameOne , "drawable", getPackageName());
            intent.putExtra("hikeImageOne",Integer.toString(resIDOne));

            String mDrawableNameTwo = imageTwo;
            int resIDTwo = getResources().getIdentifier(mDrawableNameTwo , "drawable", getPackageName());
            intent.putExtra("hikeImageTwo",Integer.toString(resIDTwo));


            intent.putExtra("latOne",hikeLatOne);
            intent.putExtra("longOne",hikeLongOne);
            intent.putExtra("latTwo",hikeLatTwo);
            intent.putExtra("longTwo",hikeLongTwo);

           // Log.i("lat", hikeLatOne);
            //double hikeLongOne = userHikeOption.getLongOne();

          //  Log.i("hike", suggestedHikeOne);

           // intent.putExtra("latOne",hikeLatOne);
            //intent.putExtra("longOne",hikeLongOne);

            intent.putExtra("infoOne",hikeInfoOne);
            intent.putExtra("infoTwo",hikeInfoTwo);

            intent.putExtra("hikeNameOne", suggestedHikeOne);
            intent.putExtra("hikeNameTwo", suggestedHikeTwo);
            startActivity(intent);
        }
    }
}
