package com.example.kaelen.hikefinder;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class HikeInfoActivity extends AppCompatActivity {

    private String userChosenHike;
    private String userInfo;
    private String userLat;
    private String userLong;
    private String hikeImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hike_info);

        Intent intent = getIntent();

        userChosenHike = intent.getStringExtra("userChosenHike");
        userInfo = intent.getStringExtra("userInfo");
        userLat = intent.getStringExtra("userLat");
        userLong = intent.getStringExtra("userLong");
        hikeImage = intent.getStringExtra("userImage");

        ImageView pic = (ImageView) findViewById(R.id.imageView);
        pic.setImageResource(Integer.parseInt(hikeImage));

        TextView hikeMessageView = (TextView) findViewById(R.id.hikeInfo);
        hikeMessageView.setText(userInfo);

        TextView messageView3 = (TextView) findViewById(R.id.textView2);
        messageView3.setText(userChosenHike);


        final Button button = (Button) findViewById(R.id.button4);

        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                seeMap(view);
            }
        };
        button.setOnClickListener(onclick);
    }

    public void seeMap(View view){
        Intent intent = new Intent(this,MapsActivity.class);


        String lat = userLat;
        intent.putExtra("userLat",lat);
        String longitude = userLong;
        intent.putExtra("userLong", longitude);
        String userHike = userChosenHike;
        intent.putExtra("userHike",userHike);

        startActivity(intent);

    }
}
