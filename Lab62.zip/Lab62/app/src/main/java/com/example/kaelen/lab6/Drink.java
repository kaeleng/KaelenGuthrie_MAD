package com.example.kaelen.lab6;

/**
 * Created by Kaelen on 12/4/2017.
 */

public class Drink {
    private String userDrink;

    private void drinkInfo(Integer drinkType, Integer drinkSweetness){
        if(drinkType == R.id.radioButton && drinkSweetness == R.id.radioButton3) {
            userDrink = "coffee with cream and sugar";
        }
        else if(drinkType == R.id.radioButton && drinkSweetness == R.id.radioButton4){
            userDrink = "black coffee";
        }
        else if(drinkType == R.id.radioButton2 && drinkSweetness == R.id.radioButton3){
            userDrink = "vanilla latte";
        }
        else if(drinkType == R.id.radioButton2 && drinkSweetness == R.id.radioButton4){
            userDrink = "latte";
        }
    }

    public void setDrinkInfo(Integer drinkType, Integer drinkSweetness){
        drinkInfo(drinkType,drinkSweetness);
    }

    public String getUserDrink(){
        return userDrink;
    }
}
