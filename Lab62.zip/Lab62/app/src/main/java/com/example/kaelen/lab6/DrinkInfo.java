package com.example.kaelen.lab6;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class DrinkInfo extends AppCompatActivity {

    private String userDrink;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drink_info);

        Intent intent = getIntent();
        userDrink = intent.getStringExtra("drinkName");

        TextView messageView = (TextView) findViewById(R.id.textView);
        messageView.setText("You should drink a " + userDrink);

    }
}
